import React from "react";

const ComponentRender = ({ data, title, target, targetData }) => {
    return (
        <div className="col-lg-4 col-sm-12 mt-3">
            <div class="card">
                <div class="card-body">
                    <p>
                        <button className="btn btn-light w-100"
                            type="button" data-bs-toggle="collapse"
                            data-bs-target={target} aria-expanded="false"
                            aria-controls="multiCollapseExample1">{title}</button>
                    </p>
                    <div class="row">
                        <div class="col">
                            <div class="collapse multi-collapse" id={targetData}>
                                <div class="card card-body">
                                    <ul class="list-group">
                                        {data?.map((elemet, index) => (
                                            <>
                                                <li key={index} class="list-group-item">
                                                    <input class="form-check-input" type="radio" name={title} id={title} />
                                                    {"  "} <label class="form-check-label" for={title}>
                                                        {elemet.itme}{elemet?.itmeSymbole}{"  :  "}{elemet?.price}{elemet.symble}
                                                    </label>
                                                </li>
                                            </>))}
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

const Subham = () => {

    return (<>
        <div className="container">
            <div className="row">
                <ComponentRender data={osData} title={"OS"} target="#OS" targetData="OS" />
                <ComponentRender data={ramData} title={"RAM"} target="#RAM" targetData="RAM" />
                <ComponentRender data={romData} title={"ROM"} target="#ROM" targetData="ROM" />
                <ComponentRender data={timeData} title={"Time"} target="#Time" targetData="Time" />
                <ComponentRender data={regionData} title={"Region"} target="#Region" targetData="Region" />
            </div>
            <div className="row justify-content-center">
                <div className="col-lg-12 col-sm-12">
                    <button className="btn btn-primary w-100 mt-3" >Submit</button>
                </div>
            </div>

        </div>
    </>)
}

export default Subham;

const osData = [
    {
        "id": "1",
        "itme": "Windows",
        "itmeSymbole": "",
        "price": "100",
        "symble": "Rs."
    },
    {
        "id": "2",
        "itme": "Linux",
        "itmeSymbole": "",
        "price": "50",
        "symble": "Rs."
    },
    {
        "id": "3",
        "itme": "MacOS",
        "itmeSymbole": "",
        "price": "200",
        "symble": "Rs."
    }
]

const ramData = [
    {
        "id": "1",
        "itme": "2",
        "itmeSymbole": "GB",
        "price": "50",
        "symble": "Rs."
    },
    {
        "id": "2",
        "itme": "4",
        "itmeSymbole": "GB",
        "price": "60",
        "symble": "Rs."
    },
    {
        "id": "3",
        "itme": "8",
        "itmeSymbole": "GB",
        "price": "80",
        "symble": "Rs."
    }
]

const romData = [
    {
        "id": "1",
        "itme": "128",
        "itmeSymbole": "GB",
        "price": "100",
        "symble": "Rs."
    },
    {
        "id": "2",
        "itme": "256",
        "itmeSymbole": "GB",
        "price": "200",
        "symble": "Rs."
    },
    {
        "id": "3",
        "itme": "512",
        "itmeSymbole": "GB",
        "price": "300",
        "symble": "Rs."
    }
]

const timeData = [
    {
        "id": "1",
        "itme": "1",
        "itmeSymbole": "hour",
        "price": "100",
        "symble": "Rs."
    },
    {
        "id": "2",
        "itme": "2",
        "itmeSymbole": "hour",
        "price": "200",
        "symble": "Rs."
    },
    {
        "id": "3",
        "itme": "3",
        "itmeSymbole": "hour",
        "price": "300",
        "symble": "Rs."
    }
]

const regionData = [
    {
        "id": "1",
        "itme": "India",
        "itmeSymbole": "",
        "price": "1000",
        "symble": "Rs."
    },
    {
        "id": "2",
        "itme": "USA",
        "itmeSymbole": "",
        "price": "2000",
        "symble": "Rs."
    },
    {
        "id": "3",
        "itme": "Pakistan",
        "itmeSymbole": "",
        "price": "3000",
        "symble": "Rs."
    }
]